public class CPU {

    public static Process CurrentProcess=new Process();
    public static   int Timer=0;
}
